public interface ItemPayable {
    abstract double getItemPaymentAmount(double x,int y);
}